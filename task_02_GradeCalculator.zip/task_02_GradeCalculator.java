import java.util.Scanner;

public class task_02_GradeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of subjects: ");
        int numSubjects;
        while (true) {
            try {
                numSubjects = Integer.parseInt(scanner.nextLine());
                if (numSubjects <= 0) {
                    System.out.println("Number of subjects must be positive. Try again.");
                    continue;
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }

        int[] marks = new int[numSubjects];
        for (int i = 0; i < numSubjects; i++) {
            while (true) {
                System.out.printf("Enter marks obtained in subject %d (out of 100): ", i + 1);
                try {
                    int mark = Integer.parseInt(scanner.nextLine());
                    if (mark < 0 || mark > 100) {
                        System.out.println("Marks must be between 0 and 100. Try again.");
                        continue;
                    }
                    marks[i] = mark;
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Please enter a valid integer.");
                }
            }
        }

        int totalMarks = 0;
        for (int mark : marks) {
            totalMarks += mark;
        }

        double averagePercentage = (double) totalMarks / numSubjects;

        String grade = calculateGrade(averagePercentage);

        System.out.println("\n--- Result ---");
        System.out.printf("Total Marks: %d out of %d%n", totalMarks, numSubjects * 100);
        System.out.printf("Average Percentage: %.2f%%%n", averagePercentage);
        System.out.println("Grade: " + grade);

        scanner.close();
    }

    private static String calculateGrade(double average) {
        if (average >= 90) {
            return "A+";
        } else if (average >= 80) {
            return "A";
        } else if (average >= 70) {
            return "B";
        } else if (average >= 60) {
            return "C";
        } else if (average >= 50) {
            return "D";
        } else {
            return "F";
        }
    }
}
